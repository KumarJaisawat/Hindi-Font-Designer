// Hindi Transliteration Engine - Rule-based mapping (no API)

const VOWELS: Record<string, string> = {
  'a': 'ा',
  'A': 'ा',
  'i': 'ि',
  'I': 'ी',
  'u': 'ु',
  'U': 'ू',
  'e': 'े',
  'E': 'े',
  'ai': 'ै',
  'o': 'ो',
  'O': 'ो',
  'au': 'ौ',
};

const CONSONANTS: Record<string, string> = {
  'k': 'क', 'kh': 'ख', 'g': 'ग', 'gh': 'घ', 'ng': 'ं',
  'ch': 'च', 'chh': 'छ', 'j': 'ज', 'jh': 'झ', 'ny': 'ञ',
  'T': 'ट', 'Th': 'ठ', 'D': 'ड', 'Dh': 'ढ', 'N': 'ण',
  't': 'त', 'th': 'थ', 'd': 'द', 'dh': 'ध', 'n': 'न',
  'p': 'प', 'ph': 'फ', 'b': 'ब', 'bh': 'भ', 'm': 'म',
  'y': 'य', 'r': 'र', 'l': 'ल', 'v': 'व',
  'sh': 'श', 'Sh': 'ष', 's': 'स', 'h': 'ह',
};

const SPECIAL: Record<string, string> = {
  ' ': ' ',
  '.': '.',
  ',': ',',
  '?': '?',
  '!': '!',
  '\n': '\n',
};

const MATRAS: Record<string, string> = {
  'a': '',
  'A': 'ा',
  'i': 'ि',
  'I': 'ी',
  'u': 'ु',
  'U': 'ू',
  'e': 'े',
  'E': 'े',
  'ai': 'ै',
  'o': 'ो',
  'O': 'ो',
  'au': 'ौ',
};

function transliterateWord(word: string): string {
  if (!word) return '';
  
  let result = '';
  let i = 0;
  
  while (i < word.length) {
    const remaining = word.slice(i).toLowerCase();
    
    // Check for two-character consonants first
    let matched = false;
    for (const [key, value] of Object.entries(CONSONANTS)) {
      if (remaining.startsWith(key.toLowerCase())) {
        result += value;
        i += key.length;
        matched = true;
        break;
      }
    }
    
    if (matched) continue;
    
    // Check for single character consonants
    const char = word[i].toLowerCase();
    if (CONSONANTS[char]) {
      result += CONSONANTS[char];
      i++;
      continue;
    }
    
    // Check for vowels at start or after consonant
    for (const [key, value] of Object.entries(VOWELS)) {
      if (remaining.startsWith(key.toLowerCase())) {
        // If it's the first character or follows a consonant, use matra
        if (result.length > 0 && MATRAS[key]) {
          result += MATRAS[key];
        } else {
          result += value;
        }
        i += key.length;
        matched = true;
        break;
      }
    }
    
    if (matched) continue;
    
    // Handle special characters
    if (SPECIAL[char]) {
      result += SPECIAL[char];
      i++;
      continue;
    }
    
    // Unknown character - keep as is
    result += word[i];
    i++;
  }
  
  // Add implicit 'a' at end if needed
  if (result.length > 0 && !['ा', 'ि', 'ी', 'ु', 'ू', 'े', 'ै', 'ो', 'ौ', 'ं', 'ः', '्'].includes(result[result.length - 1])) {
    // Check if last character is a consonant
    const lastChar = result[result.length - 1];
    const consonantValues = Object.values(CONSONANTS);
    if (consonantValues.includes(lastChar)) {
      result += 'ा';
    }
  }
  
  return result;
}

export function transliterate(text: string): string {
  if (!text) return '';
  
  // Split by spaces but preserve them
  const words = text.split(/(\s+)/);
  return words.map(word => {
    if (word.trim() === '') return word;
    return transliterateWord(word);
  }).join('');
}

export function isHindiText(text: string): boolean {
  return /[\u0900-\u097F]/.test(text);
}