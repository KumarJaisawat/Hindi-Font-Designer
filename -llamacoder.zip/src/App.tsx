import { useState, useCallback, useEffect } from "react";
import { Canvas } from "./components/Canvas";
import { Toolbar } from "./components/Toolbar";
import { BottomBar } from "./components/BottomBar";
import { transliterate, isHindiText } from "./utils/transliterate";
import { useExport } from "./hooks/useExport";

interface TextLayer {
  id: string;
  text: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  zIndex: number;
  style: {
    fontFamily: string;
    fontSize: number;
    color: string;
    fontWeight: string;
    letterSpacing: string;
    textShadow: string;
    background?: string;
    WebkitBackgroundClip?: string;
    WebkitTextFillColor?: string;
  };
}

const PRESETS: Record<string, any> = {
  'Festival Glow': {
    color: '#fbbf24',
    textShadow: '0 0 30px rgba(251, 191, 36, 0.8)',
  },
  'Bold Poster': {
    color: '#dc2626',
    textShadow: '4px 4px 0px #000',
  },
  'Elegant Script': {
    color: '#7c3aed',
    textShadow: '2px 2px 8px rgba(0,0,0,0.3)',
  },
};

function App() {
  const [layers, setLayers] = useState<TextLayer[]>([
    {
      id: '1',
      text: 'नमस्ते',
      x: 400,
      y: 300,
      rotation: 0,
      scale: 1,
      zIndex: 1,
      style: {
        fontFamily: "'Noto Serif Devanagari', serif",
        fontSize: 48,
        color: '#7c3aed',
        fontWeight: 'normal',
        letterSpacing: '0.08em',
        textShadow: '2px 2px 4px rgba(0,0,0,0.3)',
      },
    },
  ]);
  const [activeLayerId, setActiveLayerId] = useState<string | null>('1');
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);
  const [transliterateEnabled, setTransliterateEnabled] = useState(true);
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });

  const { exportCanvas, downloadImage } = useExport();

  // Load Google Fonts
  useEffect(() => {
    const fonts = [
      'Noto+Sans+Devanagari:wght@400;700',
      'Noto+Serif+Devanagari:wght@400;700',
      'Kalam:wght@400;700',
      'Poppins:wght@400;700',
      'Playfair+Display:wght@400;700',
      'Lobster:wght@400',
    ];

    fonts.forEach((font) => {
      const link = document.createElement('link');
      link.href = `https://fonts.googleapis.com/css2?family=${font}&display=swap`;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    });
  }, []);

  // Update canvas size on resize
  useEffect(() => {
    const handleResize = () => {
      setCanvasSize({
        width: window.innerWidth - 288,
        height: window.innerHeight - 80,
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const activeLayer = layers.find(l => l.id === activeLayerId);

  const handleUpdateLayer = useCallback((id: string, updates: Partial<TextLayer>) => {
    setLayers((prev) =>
      prev.map((layer) =>
        layer.id === id ? { ...layer, ...updates } : layer
      )
    );
  }, []);

  const handleUpdateStyle = useCallback((updates: Partial<TextLayer['style']>) => {
    if (!activeLayerId) return;
    handleUpdateLayer(activeLayerId, {
      style: { ...activeLayer!.style, ...updates },
    });
  }, [activeLayerId, activeLayer, handleUpdateLayer]);

  const handleAddLayer = useCallback(() => {
    const newLayer: TextLayer = {
      id: Date.now().toString(),
      text: 'नमस्ते',
      x: canvasSize.width / 2,
      y: canvasSize.height / 2,
      rotation: 0,
      scale: 1,
      zIndex: Math.max(...layers.map(l => l.zIndex), 0) + 1,
      style: {
        fontFamily: "'Noto Serif Devanagari', serif",
        fontSize: 48,
        color: '#7c3aed',
        fontWeight: 'normal',
        letterSpacing: '0.08em',
        textShadow: '2px 2px 4px rgba(0,0,0,0.3)',
      },
    };
    setLayers((prev) => [...prev, newLayer]);
    setActiveLayerId(newLayer.id);
  }, [canvasSize, layers]);

  const handleDeleteLayer = useCallback((id: string) => {
    setLayers((prev) => prev.filter((layer) => layer.id !== id));
    if (activeLayerId === id) {
      setActiveLayerId(null);
    }
  }, [activeLayerId]);

  const handleReorderLayer = useCallback((id: string, direction: 'forward' | 'backward') => {
    setLayers((prev) => {
      const layer = prev.find(l => l.id === id);
      if (!layer) return prev;

      const newZIndex = direction === 'forward' 
        ? layer.zIndex + 1 
        : Math.max(0, layer.zIndex - 1);

      return prev.map(l => l.id === id ? { ...l, zIndex: newZIndex } : l);
    });
  }, []);

  const handleImageUpload = useCallback((file: File) => {
    const url = URL.createObjectURL(file);
    setBackgroundImage(url);
  }, []);

  const handleApplyPreset = useCallback((presetName: string) => {
    const preset = PRESETS[presetName];
    if (preset && activeLayer) {
      handleUpdateStyle(preset);
    }
  }, [activeLayer, handleUpdateStyle]);

  const handleTextChange = useCallback((id: string, newText: string) => {
    let finalText = newText;
    
    if (transliterateEnabled && !isHindiText(newText)) {
      finalText = transliterate(newText);
    }
    
    handleUpdateLayer(id, { text: finalText });
  }, [transliterateEnabled, handleUpdateLayer]);

  const handleExport = useCallback(async (format: 'png' | 'jpg') => {
    try {
      const dataUrl = await exportCanvas(layers, backgroundImage, canvasSize, { format });
      const filename = `hindi-design-${Date.now()}.${format}`;
      downloadImage(dataUrl, filename);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Export failed. Please try again.');
    }
  }, [layers, backgroundImage, canvasSize, exportCanvas, downloadImage]);

  const handleShare = useCallback(() => {
    if (navigator.share) {
      navigator.share({
        title: 'My Hindi Design',
        text: 'Check out my Hindi calligraphy design!',
      }).catch(console.error);
    } else {
      alert('Sharing is not supported on this browser');
    }
  }, []);

  return (
    <div className="flex h-screen bg-gray-900 overflow-hidden">
      {/* Toolbar */}
      <Toolbar
        activeLayer={activeLayer}
        onUpdateStyle={handleUpdateStyle}
        onImageUpload={handleImageUpload}
        onApplyPreset={handleApplyPreset}
      />

      {/* Canvas */}
      <div className="flex-1 relative">
        <Canvas
          layers={layers}
          activeLayerId={activeLayerId}
          backgroundImage={backgroundImage}
          onUpdateLayer={handleUpdateLayer}
          onDeleteLayer={handleDeleteLayer}
          onSelectLayer={setActiveLayerId}
          onAddLayer={handleAddLayer}
          onReorderLayer={handleReorderLayer}
        />
      </div>

      {/* Bottom Bar */}
      <BottomBar
        transliterateEnabled={transliterateEnabled}
        onToggleTransliterate={() => setTransliterateEnabled(!transliterateEnabled)}
        onExport={handleExport}
        onShare={handleShare}
      />
    </div>
  );
}

export default App;