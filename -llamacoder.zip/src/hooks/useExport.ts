import { useRef, useCallback } from 'react';

interface TextLayer {
  id: string;
  text: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  zIndex: number;
  style: {
    fontFamily: string;
    fontSize: number;
    color: string;
    fontWeight: string;
    letterSpacing: string;
    textShadow: string;
    background?: string;
    WebkitBackgroundClip?: string;
    WebkitTextFillColor?: string;
  };
}

interface ExportOptions {
  format: 'png' | 'jpg';
  quality?: number;
  backgroundColor?: string;
}

export function useExport() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const exportCanvas = useCallback(async (
    layers: TextLayer[],
    backgroundImage: string | null,
    canvasSize: { width: number; height: number },
    options: ExportOptions = { format: 'png' }
  ): Promise<string> => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) throw new Error('Could not create canvas context');
    
    canvas.width = canvasSize.width;
    canvas.height = canvasSize.height;
    
    // Draw background
    if (options.format === 'jpg' || options.backgroundColor) {
      ctx.fillStyle = options.backgroundColor || '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    
    // Draw background image if exists
    if (backgroundImage) {
      await new Promise<void>((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve();
        };
        img.onerror = reject;
        img.src = backgroundImage;
      });
    }
    
    // Wait for fonts to load
    await document.fonts.ready;
    
    // Sort layers by z-index
    const sortedLayers = [...layers].sort((a, b) => a.zIndex - b.zIndex);
    
    // Draw each text layer
    for (const layer of sortedLayers) {
      ctx.save();
      
      // Apply transformations
      ctx.translate(layer.x, layer.y);
      ctx.rotate((layer.rotation * Math.PI) / 180);
      ctx.scale(layer.scale, layer.scale);
      
      // Apply text styles
      ctx.font = `${layer.style.fontWeight} ${layer.style.fontSize}px ${layer.style.fontFamily}`;
      ctx.fillStyle = layer.style.color;
      ctx.letterSpacing = parseFloat(layer.style.letterSpacing) || 0;
      
      // Apply text shadow
      if (layer.style.textShadow) {
        const shadowMatch = layer.style.textShadow.match(/(\d+)px\s+(\d+)px\s+(\d+)px\s+(.+)/);
        if (shadowMatch) {
          ctx.shadowColor = shadowMatch[4];
          ctx.shadowOffsetX = parseInt(shadowMatch[1]);
          ctx.shadowOffsetY = parseInt(shadowMatch[2]);
          ctx.shadowBlur = parseInt(shadowMatch[3]);
        }
      }
      
      // Handle gradient text
      if (layer.style.background && layer.style.WebkitBackgroundClip === 'text') {
        const gradientMatch = layer.style.background.match(/linear-gradient\((.+)\)/);
        if (gradientMatch) {
          const gradient = ctx.createLinearGradient(0, 0, ctx.measureText(layer.text).width, 0);
          const colors = gradientMatch[1].split(',').map(c => c.trim());
          colors.forEach((color, index) => {
            gradient.addColorStop(index / (colors.length - 1), color);
          });
          ctx.fillStyle = gradient;
        }
      }
      
      // Draw text
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'center';
      ctx.fillText(layer.text, 0, 0);
      
      ctx.restore();
    }
    
    // Export
    const dataUrl = canvas.toDataURL(
      `image/${options.format}`,
      options.quality || 1
    );
    
    return dataUrl;
  }, []);

  const downloadImage = useCallback((dataUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.download = filename;
    link.href = dataUrl;
    link.click();
  }, []);

  return { exportCanvas, downloadImage };
}