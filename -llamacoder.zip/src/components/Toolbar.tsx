import { Type, Palette, Image as ImageIcon, Sparkles } from "lucide-react";
import { Input } from "/components/ui/input";
import { Label } from "/components/ui/label";
import { PreviewCard } from "./PreviewCard";

interface ToolbarProps {
  activeLayer: any;
  onUpdateStyle: (updates: any) => void;
  onImageUpload: (file: File) => void;
  onApplyPreset: (preset: string) => void;
}

const CALLIGRAPHY_STYLES = [
  {
    name: 'Traditional',
    className: 'font-serif',
    fontFamily: "'Noto Serif Devanagari', serif",
    letterSpacing: '0.08em',
    textShadow: '2px 2px 4px rgba(0,0,0,0.3)',
  },
  {
    name: 'Modern Bold',
    className: 'font-sans font-bold',
    fontFamily: "'Noto Sans Devanagari', sans-serif",
    letterSpacing: '0.02em',
    textShadow: 'none',
  },
  {
    name: 'Elegant Script',
    className: 'font-serif italic',
    fontFamily: "'Noto Serif Devanagari', serif",
    letterSpacing: '0.12em',
    textShadow: '1px 1px 2px rgba(0,0,0,0.2)',
  },
  {
    name: 'Festive Glow',
    className: 'font-bold',
    fontFamily: "'Noto Sans Devanagari', sans-serif",
    letterSpacing: '0.05em',
    textShadow: '0 0 20px rgba(168, 85, 247, 0.8), 0 0 40px rgba(168, 85, 247, 0.6)',
  },
  {
    name: 'Neon Style',
    className: 'font-bold',
    fontFamily: "'Noto Sans Devanagari', sans-serif",
    letterSpacing: '0.1em',
    textShadow: '0 0 10px #00ff00, 0 0 20px #00ff00, 0 0 30px #00ff00',
  },
  {
    name: 'Vintage',
    className: 'font-serif',
    fontFamily: "'Noto Serif Devanagari', serif",
    letterSpacing: '0.15em',
    textShadow: '3px 3px 0px rgba(139, 92, 246, 0.5)',
  },
];

const FONTS = [
  { name: 'Noto Sans Devanagari', category: 'sans-serif' },
  { name: 'Noto Serif Devanagari', category: 'serif' },
  { name: 'Kalam', category: 'handwriting' },
  { name: 'Poppins', category: 'sans-serif' },
  { name: 'Playfair Display', category: 'serif' },
  { name: 'Lobster', category: 'display' },
];

const PRESETS = [
  { name: 'Festival Glow', color: '#fbbf24', shadow: '0 0 30px rgba(251, 191, 36, 0.8)' },
  { name: 'Bold Poster', color: '#dc2626', shadow: '4px 4px 0px #000' },
  { name: 'Elegant Script', color: '#7c3aed', shadow: '2px 2px 8px rgba(0,0,0,0.3)' },
];

export function Toolbar({ activeLayer, onUpdateStyle, onImageUpload, onApplyPreset }: ToolbarProps) {
  if (!activeLayer) {
    return (
      <div className="w-72 bg-gray-900/80 backdrop-blur-lg border-r border-purple-500/30 p-4 flex flex-col items-center justify-center text-purple-200">
        <Type className="w-12 h-12 mb-4 opacity-50" />
        <p className="text-center text-sm">Select a text layer to edit its properties</p>
      </div>
    );
  }

  return (
    <div className="w-72 bg-gray-900/80 backdrop-blur-lg border-r border-purple-500/30 p-4 overflow-y-auto">
      {/* Calligraphy Styles */}
      <div className="mb-6">
        <h3 className="text-purple-200 font-semibold mb-3 flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          Calligraphy Styles
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {CALLIGRAPHY_STYLES.map((style, index) => (
            <PreviewCard
              key={index}
              style={style}
              isSelected={activeLayer.style.fontFamily === style.fontFamily}
              onClick={() => onUpdateStyle({
                fontFamily: style.fontFamily,
                letterSpacing: style.letterSpacing,
                textShadow: style.textShadow,
              })}
            />
          ))}
        </div>
      </div>

      {/* Font Selection */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2 flex items-center gap-2">
          <Type className="w-4 h-4" />
          Font Family
        </Label>
        <select
          value={activeLayer.style.fontFamily}
          onChange={(e) => onUpdateStyle({ fontFamily: e.target.value })}
          className="w-full bg-gray-800 text-purple-100 border border-purple-500/30 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          {FONTS.map((font) => (
            <option key={font.name} value={`'${font.name}', ${font.category}`}>
              {font.name}
            </option>
          ))}
        </select>
      </div>

      {/* Text Color */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2 flex items-center gap-2">
          <Palette className="w-4 h-4" />
          Text Color
        </Label>
        <div className="flex gap-2 items-center">
          <Input
            type="color"
            value={activeLayer.style.color}
            onChange={(e) => onUpdateStyle({ color: e.target.value })}
            className="w-12 h-10 p-1 rounded cursor-pointer"
          />
          <Input
            type="text"
            value={activeLayer.style.color}
            onChange={(e) => onUpdateStyle({ color: e.target.value })}
            className="flex-1 bg-gray-800 text-purple-100 border border-purple-500/30 rounded-lg px-3 py-2"
          />
        </div>
      </div>

      {/* Font Size */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2">Font Size</Label>
        <Input
          type="range"
          min="12"
          max="120"
          value={activeLayer.style.fontSize}
          onChange={(e) => onUpdateStyle({ fontSize: parseInt(e.target.value) })}
          className="w-full"
        />
        <span className="text-purple-300 text-sm">{activeLayer.style.fontSize}px</span>
      </div>

      {/* Letter Spacing */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2">Letter Spacing</Label>
        <Input
          type="range"
          min="-5"
          max="20"
          step="0.5"
          value={parseFloat(activeLayer.style.letterSpacing)}
          onChange={(e) => onUpdateStyle({ letterSpacing: `${e.target.value}em` })}
          className="w-full"
        />
        <span className="text-purple-300 text-sm">{activeLayer.style.letterSpacing}</span>
      </div>

      {/* Text Shadow */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2">Text Shadow</Label>
        <Input
          type="text"
          value={activeLayer.style.textShadow}
          onChange={(e) => onUpdateStyle({ textShadow: e.target.value })}
          placeholder="e.g., 2px 2px 4px rgba(0,0,0,0.3)"
          className="w-full bg-gray-800 text-purple-100 border border-purple-500/30 rounded-lg px-3 py-2 text-sm"
        />
      </div>

      {/* Quick Presets */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2">Quick Presets</Label>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset.name}
              onClick={() => onApplyPreset(preset.name)}
              className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg transition-colors"
            >
              {preset.name}
            </button>
          ))}
        </div>
      </div>

      {/* Background Image */}
      <div className="mb-6">
        <Label className="text-purple-200 font-semibold mb-2 flex items-center gap-2">
          <ImageIcon className="w-4 h-4" />
          Background Image
        </Label>
        <Input
          type="file"
          accept="image/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onImageUpload(file);
          }}
          className="w-full bg-gray-800 text-purple-100 border border-purple-500/30 rounded-lg px-3 py-2"
        />
      </div>
    </div>
  );
}