import { Download, Share2, Languages } from "lucide-react";
import { Button } from "/components/ui/button";

interface BottomBarProps {
  transliterateEnabled: boolean;
  onToggleTransliterate: () => void;
  onExport: (format: 'png' | 'jpg') => void;
  onShare: () => void;
}

export function BottomBar({
  transliterateEnabled,
  onToggleTransliterate,
  onExport,
  onShare,
}: BottomBarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900/90 backdrop-blur-lg border-t border-purple-500/30 px-6 py-4 flex items-center justify-between z-50">
      {/* Transliterate Toggle */}
      <div className="flex items-center gap-3">
        <Languages className="w-5 h-5 text-purple-300" />
        <div className="flex items-center gap-2">
          <span className="text-purple-200 text-sm">Auto-Transliterate</span>
          <button
            onClick={onToggleTransliterate}
            className={`
              relative w-12 h-6 rounded-full transition-colors duration-200
              ${transliterateEnabled ? 'bg-purple-600' : 'bg-gray-700'}
            `}
          >
            <span
              className={`
                absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-200
                ${transliterateEnabled ? 'translate-x-7' : 'translate-x-1'}
              `}
            />
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-3">
        <Button
          onClick={() => onExport('png')}
          className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all duration-200"
        >
          <Download className="w-4 h-4" />
          Export PNG
        </Button>
        <Button
          onClick={() => onExport('jpg')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all duration-200"
        >
          <Download className="w-4 h-4" />
          Export JPG
        </Button>
        <Button
          onClick={onShare}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all duration-200"
        >
          <Share2 className="w-4 h-4" />
          Share
        </Button>
      </div>
    </div>
  );
}