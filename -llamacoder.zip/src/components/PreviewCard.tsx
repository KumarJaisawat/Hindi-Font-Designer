import { Card } from "/components/ui/card";
import { Check } from "lucide-react";

interface CalligraphyStyle {
  name: string;
  className: string;
  fontFamily: string;
  letterSpacing: string;
  textShadow: string;
  stroke?: string;
}

interface PreviewCardProps {
  style: CalligraphyStyle;
  isSelected: boolean;
  onClick: () => void;
}

export function PreviewCard({ style, isSelected, onClick }: PreviewCardProps) {
  return (
    <Card
      onClick={onClick}
      className={`
        relative cursor-pointer transition-all duration-200
        hover:scale-105 hover:shadow-xl
        ${isSelected ? 'ring-2 ring-purple-500 shadow-lg' : 'hover:ring-1 hover:ring-purple-300'}
      `}
    >
      <div className="p-4">
        <div
          className={`
            h-20 flex items-center justify-center text-2xl
            ${style.className}
          `}
          style={{
            fontFamily: style.fontFamily,
            letterSpacing: style.letterSpacing,
            textShadow: style.textShadow,
            WebkitTextStroke: style.stroke,
          }}
        >
          नमस्ते
        </div>
        <p className="text-xs text-center mt-2 text-gray-600 truncate">
          {style.name}
        </p>
      </div>
      
      {isSelected && (
        <div className="absolute top-2 right-2 bg-purple-500 rounded-full p-1">
          <Check className="w-3 h-3 text-white" />
        </div>
      )}
    </Card>
  );
}