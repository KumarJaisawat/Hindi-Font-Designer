import { useState, useRef, useEffect, useCallback } from 'react';
import { Move, RotateCw, Maximize2, Trash2, Layers } from 'lucide-react';

interface TextLayer {
  id: string;
  text: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  zIndex: number;
  style: {
    fontFamily: string;
    fontSize: number;
    color: string;
    fontWeight: string;
    letterSpacing: string;
    textShadow: string;
    background?: string;
    WebkitBackgroundClip?: string;
    WebkitTextFillColor?: string;
  };
}

interface CanvasProps {
  layers: TextLayer[];
  activeLayerId: string | null;
  backgroundImage: string | null;
  onUpdateLayer: (id: string, updates: Partial<TextLayer>) => void;
  onDeleteLayer: (id: string) => void;
  onSelectLayer: (id: string | null) => void;
  onAddLayer: () => void;
  onReorderLayer: (id: string, direction: 'forward' | 'backward') => void;
}

export function Canvas({
  layers,
  activeLayerId,
  backgroundImage,
  onUpdateLayer,
  onDeleteLayer,
  onSelectLayer,
  onAddLayer,
  onReorderLayer,
}: CanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isRotating, setIsRotating] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [layerStart, setLayerStart] = useState({ x: 0, y: 0, rotation: 0, scale: 1 });

  const activeLayer = layers.find(l => l.id === activeLayerId);

  const handleMouseDown = useCallback((e: React.MouseEvent, layerId: string, action: 'drag' | 'rotate' | 'resize') => {
    e.stopPropagation();
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;

    onSelectLayer(layerId);
    setDragStart({ x: e.clientX, y: e.clientY });
    setLayerStart({ x: layer.x, y: layer.y, rotation: layer.rotation, scale: layer.scale });

    if (action === 'drag') setIsDragging(true);
    else if (action === 'rotate') setIsRotating(true);
    else if (action === 'resize') setIsResizing(true);
  }, [layers, onSelectLayer]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!activeLayer) return;

    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;

    if (isDragging) {
      onUpdateLayer(activeLayer.id, {
        x: layerStart.x + dx,
        y: layerStart.y + dy,
      });
    } else if (isRotating) {
      const canvasRect = canvasRef.current?.getBoundingClientRect();
      if (!canvasRect) return;
      
      const centerX = canvasRect.left + layerStart.x;
      const centerY = canvasRect.top + layerStart.y;
      const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
      const rotation = (angle * 180) / Math.PI + 90;
      
      onUpdateLayer(activeLayer.id, { rotation });
    } else if (isResizing) {
      const newScale = Math.max(0.2, layerStart.scale + dx / 100);
      onUpdateLayer(activeLayer.id, { scale: newScale });
    }
  }, [activeLayer, dragStart, layerStart, isDragging, isRotating, isResizing, onUpdateLayer]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsRotating(false);
    setIsResizing(false);
  }, []);

  useEffect(() => {
    if (isDragging || isRotating || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isRotating, isResizing, handleMouseMove, handleMouseUp]);

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (e.target === canvasRef.current) {
      onSelectLayer(null);
    }
  };

  return (
    <div
      ref={canvasRef}
      onClick={handleCanvasClick}
      className="relative w-full h-full overflow-hidden bg-gray-100"
      style={{
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Add layer button */}
      <button
        onClick={onAddLayer}
        className="absolute top-4 right-4 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-xl shadow-lg transition-all duration-200 flex items-center gap-2 z-50"
      >
        <Layers className="w-4 h-4" />
        Add Text
      </button>

      {/* Render layers */}
      {layers.map((layer) => {
        const isActive = layer.id === activeLayerId;
        
        return (
          <div
            key={layer.id}
            className={`absolute cursor-move select-none ${isActive ? 'z-50' : ''}`}
            style={{
              left: layer.x,
              top: layer.y,
              transform: `rotate(${layer.rotation}deg) scale(${layer.scale})`,
              zIndex: layer.zIndex,
            }}
            onMouseDown={(e) => handleMouseDown(e, layer.id, 'drag')}
          >
            {/* Text content */}
            <div
              contentEditable={isActive}
              suppressContentEditableWarning
              className="outline-none text-center whitespace-nowrap"
              style={{
                fontFamily: layer.style.fontFamily,
                fontSize: layer.style.fontSize,
                color: layer.style.color,
                fontWeight: layer.style.fontWeight,
                letterSpacing: layer.style.letterSpacing,
                textShadow: layer.style.textShadow,
                background: layer.style.background,
                WebkitBackgroundClip: layer.style.WebkitBackgroundClip,
                WebkitTextFillColor: layer.style.WebkitTextFillColor,
              }}
              onBlur={(e) => onUpdateLayer(layer.id, { text: e.currentTarget.textContent || '' })}
            >
              {layer.text}
            </div>

            {/* Selection controls */}
            {isActive && (
              <>
                {/* Rotation handle */}
                <div
                  className="absolute -top-8 left-1/2 -translate-x-1/2 w-6 h-6 bg-purple-500 rounded-full cursor-pointer flex items-center justify-center"
                  onMouseDown={(e) => handleMouseDown(e, layer.id, 'rotate')}
                >
                  <RotateCw className="w-3 h-3 text-white" />
                </div>

                {/* Resize handle */}
                <div
                  className="absolute -bottom-2 -right-2 w-6 h-6 bg-blue-500 rounded-full cursor-pointer flex items-center justify-center"
                  onMouseDown={(e) => handleMouseDown(e, layer.id, 'resize')}
                >
                  <Maximize2 className="w-3 h-3 text-white" />
                </div>

                {/* Delete button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteLayer(layer.id);
                  }}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
                >
                  <Trash2 className="w-3 h-3 text-white" />
                </button>

                {/* Layer controls */}
                <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 flex gap-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onReorderLayer(layer.id, 'forward');
                    }}
                    className="bg-gray-800 text-white px-2 py-1 rounded text-xs hover:bg-gray-700"
                  >
                    ↑
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onReorderLayer(layer.id, 'backward');
                    }}
                    className="bg-gray-800 text-white px-2 py-1 rounded text-xs hover:bg-gray-700"
                  >
                    ↓
                  </button>
                </div>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}